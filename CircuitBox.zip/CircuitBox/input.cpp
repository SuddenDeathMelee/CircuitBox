#include "input.h"

input::input(string label_) : logic_object(){
	label=label_;
}
input::input(string label_, bool value_) :logic_object(value_){
	label=label_;
	value=value_;
}
void input::switch_value(){
	value=!(value);
	output->restructure();
}
