#include <vector>
#include <stdlib.h>
#include <string>

#include "logic_object.h"
#include "AND_gate.h"
#include "input.h"

using namespace std;

int main(){
	vector<logic_object*> inputs;
	
	input Var_A("A", false);
	inputs.push_back(&Var_A);
	input Var_B("B", false);
	inputs.push_back(&Var_B);
	
	AND_gate component_2(inputs);
	
	component_2.evaluate();
	component_2.print();
	
}