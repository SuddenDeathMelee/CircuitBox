#include <stdlib.h>
#include <iostream>
#include "OR_gate.h"

OR_gate::OR_gate() : logic_object(){
	label="OR gate";
}
OR_gate::OR_gate(vector<logic_object*> inputs_) : logic_object(inputs_){
	label="OR gate";
}
OR_gate::OR_gate(vector<logic_object*> inputs_, string label_) : logic_object(inputs_){
	label=label_;
}
bool OR_gate::evaluate(){
	value=false;
	
	/*
	OR_gate searches through its inputs until it finds a 1,
	then returns true. Otherwise, it returns false.
	*/
	
	for(int i=0; i<inputs.size(); i++){
		if((inputs[i]->value)){
			value=true;
			break;
		}
	}
	return value;
}
bool OR_gate::restructure(){
	bool prev_value=value;
	
	evaluate();

	/*
	only call restructure on the next component if the value
	of this component has changed. Returns once output points
	to NULL (i.e. there is no next component)
	*/
	
	if(output && (prev_value!=value)){
		output->restructure();
	}
	return value;
}
