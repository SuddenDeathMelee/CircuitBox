#pragma once
#include <stdlib.h>
#include "logic_object.h"

class XNOR_gate: public logic_object{
	public:
		//CONSTRUCTORS
		XNOR_gate();
		XNOR_gate(vector<logic_object*> inputs_);
		XNOR_gate(vector<logic_object*> inputs_, string label_);
		//LOGIC FUNCTIONS
		bool evaluate();
		bool restructure();
};
