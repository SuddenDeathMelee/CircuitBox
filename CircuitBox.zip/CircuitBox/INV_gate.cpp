#include <stdlib.h>
#include <iostream>
#include "INV_gate.h"

INV_gate::INV_gate() : logic_object(){
	label="AND gate";
}
INV_gate::INV_gate(vector<logic_object*> inputs_) : logic_object(inputs_){
	label="INV gate";
}
INV_gate::INV_gate(vector<logic_object*> inputs_, string label_) : logic_object(inputs_){
	label=label_;
}
bool INV_gate::evaluate(){
	/*
	INV_gate evaluate inverts the value of it's input
	and stores in in value
	*/
	value=!(inputs[0]->value);
	return value;

}
bool INV_gate::restructure(){
	bool prev_value=value;
	
	evaluate();
	
	/*
	only call restructure on the next component if the value
	of this component has changed. Returns once output points
	to NULL (i.e. there is no next component)
	*/
	
	if(output && (prev_value!=value)){
		output->restructure();
	}
	return value;	
}
