#pragma once
#include <stdlib.h>
#include "logic_object.h"

class NAND_gate: public logic_object{
	public:
		//CONSTRUCTORS
		NAND_gate();
		NAND_gate(vector<logic_object*> inputs_);
		NAND_gate(vector<logic_object*> inputs_, string label_);
		//LOGIC FUNCTIONS
		bool evaluate();
		bool restructure();
};