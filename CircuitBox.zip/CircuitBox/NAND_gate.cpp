#include <stdlib.h>
#include <iostream>
#include "NAND_gate.h"

NAND_gate::NAND_gate() : logic_object(){
	label="NAND gate";
}
NAND_gate::NAND_gate(vector<logic_object*> inputs_) : logic_object(inputs_){
	label="NAND gate";
}
NAND_gate::NAND_gate(vector<logic_object*> inputs_, string label_) : logic_object(inputs_){
	label=label_;
}
bool NAND_gate::evaluate(){
	value=false;
	
	/*
	AND_gate evaluate will search for a 0 and returns true
	if it does so. It will return false otherwise.
	*/
	
	for(int i=0; i<inputs.size(); i++){
		if(!(inputs[i]->value)){
			value=true;
			break;
		}
	}
	return value;
}
bool NAND_gate::restructure(){
	bool prev_value=value;
	
	evaluate();
	
	/*
	only call restructure on the next component if the value
	of this component has changed. Returns once output points
	to NULL (i.e. there is no next component)
	*/
	
	if(output && (prev_value!=value)){
		output->restructure();
	}
	return value;
}
