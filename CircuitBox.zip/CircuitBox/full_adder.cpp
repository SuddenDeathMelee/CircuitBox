#include <stdlib.h>
#include <vector>
#include <list>
#include <iostream>
#include "logic_object.h"
#include "input.h"
#include "circuit.h"
#include "AND_gate.h"
#include "OR_gate.h"
#include "XOR_gate.h"

int main(){
	vector<string> outputs;
	outputs.push_back("S");
	outputs.push_back("COUT");
	
	vector<input> inputs_AND_1;
	input Var_A("A",true);
	inputs_AND_1.push_back(Var_A);
	input Var_B("B",true);
	inputs_AND_1.push_back(Var_B);
	
	AND_gate AND_element_1;
	
	circuit full_adder(inputs_AND_1);
	full_adder.add_element(AND_element_1, inputs_AND_1);
	
	vector<input> inputs_XOR_1;
	inputs_XOR_1.push_back(Var_A);
	inputs_XOR_1.push_back(Var_B);
	
	XOR_gate XOR_element_1;
	
	full_adder.add_element(XOR_element_1, inputs_XOR_1);
	
	vector<input> inputs_XOR_2;
	input Var_CIN("CIN",true);
	inputs_XOR_2.push_back(Var_CIN);
	
	XOR_gate XOR_element_2;
	
	vector<logic_object*> component_inputs_XOR_2;
	component_inputs_XOR_2.push_back(&XOR_element_1);
	
	full_adder.add_element(XOR_element_2, component_inputs_XOR_2, inputs_XOR_2);
	
	vector<input> inputs_AND_2;
	inputs_AND_2.push_back(Var_CIN);
	
	AND_gate AND_element_2;
	
	vector<logic_object*> component_inputs_AND_2;
	component_inputs_AND_2.push_back(&XOR_element_1);
	
	full_adder.add_element(AND_element_2, component_inputs_AND_2, inputs_AND_2);
	
	OR_gate OR_gate_1;
	
	vector<logic_object*> component_inputs_OR_1;
	component_inputs_OR_1.push_back(&AND_element_1);
	component_inputs_OR_1.push_back(&AND_element_2);
	
	full_adder.add_element(OR_gate_1, component_inputs_OR_1);
	full_adder.set_output_labels(outputs);
	full_adder.evaluate();
	
	cout<<"AND_element_1 value:"<<endl;
	AND_element_1.print_value(); 
	cout<<endl;
	cout<<"XOR_element_1 value:"<<endl;
	XOR_element_1.print_value();
	cout<<endl;
	cout<<"XOR_element_2 value:"<<endl;
	XOR_element_2.print_value();
	cout<<endl;
	cout<<"AND_element_2 value:"<<endl;
	AND_element_2.print_value();
	cout<<endl;
	cout<<"OR_element_1 value:"<<endl;
	OR_gate_1.print_value();
	cout<<endl;
	cout<<"FULL ADDER:"<<endl;
	full_adder.print_value();	
}