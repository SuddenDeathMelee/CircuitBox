#pragma once
#include <stdlib.h>
#inculde <vector>
#include <list>
#include "logic_object.h"
#include "input.h"

using namespace std;

class circuit{
	public:
		circuit(vector<input>& _inputs){
			inputs=_inputs; //Declare initial inputs
		}
		void add_element(logic_object& element, vector<input>& variables);//Add stand-alone element- not connected to any other components
		void add_element(logic_object& element, vector<logic_object*> elements);//Add an element whose inputs are the outputs of other elements
		void add_element(logic_object& element, vector<logic_object*> elements, vector<input>& variables);//Add an element whose inputs are a combination of components and variables
		vector<bool> evaluate();
		void print_value();
		void set_output_labels(vector<string> labels);
	private:
	vector<input> inputs;
	list<logic_object*> outputs;
	vector<bool> logic_values;
	vector<string> output_labels;
};