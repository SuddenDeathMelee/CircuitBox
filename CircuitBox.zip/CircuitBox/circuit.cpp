void circuit::add_element(logic_object& element, vector<input>& variables){
	for(int i=0; i<variables.size(); ++i){
		variables[i].add_output(&element);
		element.add_inputs(&element);
		element.add_input(variables[i]);
	}
	element.evaluate();//update truth value of element
	
	outputs.push_back(&element);//component is considered an output of the circuit at this point
}

void circuit::add_element(logic_object& element, vector<logic_object*> elements){
	
}

void circuit::add_element(logic_object& element, vector<logic_object*> elements, vector<input>& variables){
	
}
