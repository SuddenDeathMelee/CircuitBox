#include <stdlib.h>
#include <vector>
#include <list>
#include <iostream>
#include "logic_object.h"
#include "circuit.h"
using namespace std;
void circuit::add_element(logic_object& element, vector<input>& variables){
	for(int i=0; i<variables.size(); ++i){
		variables[i].add_output(&element);
		element.add_inputs(variables[i]); //Add variables as inputs of element-
	}
	element.evaluate();//update truth value of elements
	
	//Update inputs - add variable in input.cpp that points to the circuit it's in? So we don't have to do a search through inputs because that'd be a bitch
	outputs.push_back(&element); //component is considered an output of the circuit at this point
}
void circuit::add_element(logic_object& element, vector<logic_object*> elements){
	for(int i=0; i<elements.size(); ++i){
	list<logic_object*>::iterator output_itr;
		for(output_itr=outputs.begin(); output_itr!=outputs.end(); ){
			if((elements[i])==*output_itr){ //if one of the elements was an output of the circuit, it no longer is
				output_itr=outputs.erase(output_itr); //remove as circuit output
			}
			else
				output_itr++;
		}
	}
	for(int j=0; j<elements.size(); ++j){
		(*elements[j]).add_output(&element);
		element.add_inputs(*(elements[j])); //Add inputs to new component
	}
	element.evaluate();//update truth value of elements
	outputs.push_back(&element);
}
void circuit::add_element(logic_object& element, vector<logic_object*> elements, vector<input>& variables){
	for(int i=0; i<variables.size(); ++i){
		variables[i].add_output(&element);
		element.add_inputs(variables[i]); //Add variables as inputs of element-
	}
	for(int i=0; i<elements.size(); ++i){
	list<logic_object*>::iterator output_itr;
		for(output_itr=outputs.begin(); output_itr!=outputs.end(); ){
			if((elements[i])==*output_itr){ //if one of the elements was an output of the circuit, it no longer is
				output_itr=outputs.erase(output_itr); //remove as circuit output
			}
			else
				output_itr++;
		}
	}
	for(int j=0; j<elements.size(); ++j){
		(*elements[j]).add_output(&element);
		element.add_inputs(*(elements[j])); //Add inputs to new component
	}
	element.evaluate();//update truth value of elements
	outputs.push_back(&element);
	/*add_element(element, elements);
	add_element(element, variables);*/ //FIXME:: Don't be fuckin lazy, seriously, figure out how to do this 
}
vector<bool> circuit::evaluate(){
	vector<bool> new_values;
	list<logic_object*>::iterator itr;
	for(itr=outputs.begin(); itr!=outputs.end();++itr){
		new_values.push_back((*itr)->evaluate());
	}
	logic_value=new_values;
	return logic_value;
}
void circuit::print_value(){
	for(int i=0; i<logic_value.size();++i){
		if(logic_value[i])
			cout<<"The truth value of "<<output_labels[i]<<" is "<<1<<endl;
		else
			cout<<"The truth value of "<<output_labels[i]<<" is "<<0<<endl;
	}
}
void circuit::set_output_labels(vector<string> labels){
	output_labels=labels;
}