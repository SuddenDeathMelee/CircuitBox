#include <stdlib.h>
#include <iostream>
#include "AND_gate.h"

AND_gate::AND_gate() : logic_object(){
	label="AND gate";
}
AND_gate::AND_gate(vector<logic_object*> inputs_) : logic_object(inputs_){
	label="AND gate";
}
AND_gate::AND_gate(vector<logic_object*> inputs_, string label_) : logic_object(inputs_){
	label=label_;
}
bool AND_gate::evaluate(){
	value=true;
	
	/*
	AND_gate evaluate will search for a 0 and returns false
	if it does so. It will return true otherwise.
	*/
	
	for(int i=0; i<inputs.size(); i++){
		if(!(inputs[i]->value)){
			value=false;
			break;
		}
	}
	return value;
}
bool AND_gate::restructure(){
	bool prev_value=value;
	
	evaluate();
	
	/*
	only call restructure on the next component if the value
	of this component has changed. Returns once output points
	to NULL (i.e. there is no next component)
	*/
	
	if(output && (prev_value!=value))
		output->restructure();
	
	return value;
}
