#pragma once
#include <stdlib.h>
#include "logic_object.h"

class OR_gate: public logic_object{
	public:
		//CONSTRUCTORS
		OR_gate();
		OR_gate(vector<logic_object*> inputs_);
		OR_gate(vector<logic_object*> inputs_, string label_);
		//LOGIC FUNCTIONS
		bool evaluate();
		bool restructure();
};