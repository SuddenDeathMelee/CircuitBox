#pragma once
#include <stdlib.h>
#include "logic_object.h"

class XOR_gate: public logic_object{
	public:
		//CONSTRUCTORS
		XOR_gate();
		XOR_gate(vector<logic_object*> inputs_);
		XOR_gate(vector<logic_object*> inputs_, string label_);
		//LOGIC FUNCTIONS
		bool evaluate();
		bool restructure();
};
