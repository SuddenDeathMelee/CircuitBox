#include <stdlib.h>
#include <iostream>
#include "NOR_gate.h"

NOR_gate::NOR_gate() : logic_object(){
	label="NOR gate";
}
NOR_gate::NOR_gate(vector<logic_object*> inputs_) : logic_object(inputs_){
	label="NOR gate";
}
NOR_gate::NOR_gate(vector<logic_object*> inputs_, string label_) : logic_object(inputs_){
	label=label_;
}
bool NOR_gate::evaluate(){
	value=true;
	
	/*
	NOR_gate evaluate will search for a 1 and returns false
	if it does so. It will return true otherwise.
	*/
	
	for(int i=0; i<inputs.size(); i++){
		if((inputs[i]->value)){
			value=false;
			break;
		}
	}
	return value;
}
bool NOR_gate::restructure(){
	bool prev_value=value;
	
	evaluate();
	
	/*
	only call restructure on the next component if the value
	of this component has changed. Returns once output points
	to NULL (i.e. there is no next component)
	*/
	
	if(output && (prev_value!=value)){
		output->restructure();
	}
	return value;
}
