#include <list>
#include "Chip.h"
using namespace std;

bool Chip::is_chip(){
	return true;
}