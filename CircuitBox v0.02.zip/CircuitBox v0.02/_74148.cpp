#include "_74148.h"

void _74148::pin_to_output(logic_object* output, int pin_input, int pin_output){
	output_objects[pin]=output;
	pin connected_pin;
	connected_pin.output_pin=pin_output;
	connected_pin.value=output[pin_input];
	pins[output].push_back(connected_pin);
}

void _74148::input_to_pin(logic_object* input, int pin){
	inputs[pin]=input;
}

void _74148::evaluate(){
	int grounded_pin=8;
	if(enabled()){
		for(int i=8;i>0;i--){
			if(inputs[i]->is_chip()){
				if(!(inputs[i]->value(this,i)){
					grounded_pin=i-1;
					break;
				}
			}
			else{
				if(!(inputs[i]->value())){
					grounded_pin=i-1;
					break;
				}
			}
		
		}
	}
	else{
		for(int i=0; i<5; i++){
			outputs[i]=1;
		}
		return;
	}
	if(grounded_pin==9){
		
		for(int i=0;i<4;i++){
			outputs[i]=1;
		}
		outputs[4]=0;
		
		return;
	}
	int number= 7-grounded_pin;
	for(int i=0; i<3; ++i){
		int temp= number%2;
		if(temp==1){
			outputs[pin]=1;
		}
		else
			outputs[pin]=0;
		number=number/2;
	}
	outputs[3]=0;
	outputs[4]=1;
}

bool _74148::enabled(){
	if(inputs[0]){
		if(inputs[0]->is_chip()){
			if((inputs[0]->value(this, 0)))
				return false;
			else
				return true;
		}
		else
			if((inputs[0]->value()))
				return false;
			else
				return false;
	}
	else
		return false;
}

void _74148::restructure(){
	vector<bool> prev_output;
	
	
	for(int i=0; i<8; ++i)
		prev_output.push_back(outputs[i]);
	
	evaluate();
	
	for(int i=0; i<8; i++){
		if(prev_output!=outputs[i])
			output_objects[i]->restructure();
	}
}
vector<bool> _74148::value(logic_object* obj){
	vector<bool> pin_values;
	list<pin> pin_numbers= pins[obj];
	list<pin>::iterator pin_itr= pin_numbers.begin();
	
	while(pin_itr!=pin_numbers.end()){
		int pin_value=pin_itr->value;
		pin_values.push_back(outputs[pin_value]);
		pin_itr++;
	}
	return pin_values;
}

bool _74148::value(logic_object* obj, int pin_){
	int value;
	list<pin> pin_numbers= pins[obj];
	list<pin>::iterator pin_itr= pin_numbers.begin();
	
	while(pin_itr!=pin_numbers.end()){
		if(pin_itr->output_pin==pin_){
			return pin_itr->value;
		}
	}
	return 0;
}

bool _74148::outputs_filled(){
	if(pins.size()==num_outputs)
		return true;
	return false;
}

bool _74148::output_connected(int pin){
	if(output_objects[pin])
		return true;
	else
		return false;
}

void _74148::print_value(){
	for(int i=0; i<5; ++i){
		cout<<"Value of pin "<<i<<" is: "<<outputs[i]<<endl;
	}
}