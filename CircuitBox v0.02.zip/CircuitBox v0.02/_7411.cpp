#include "_7411.h"

/*
pin_to_output stores a logic_object* in output_objects; a pin from this chip is connected to
another logic_object. This function ensures that a new pin object is stored in 
the pins data structure so that this object can know which elements are connected to which
pins
*/
void _7411::pin_to_output(logic_object* output, int pin_input, int pin_output){
	output_objects[pin]=output;
	pin connected_pin;
	connected_pin.output_pin=pin_output;
	connected_pin.value=output[pin_input];
	pins[output].push_back(connected_pin);
}

/*
input_to_pin stores a logic_object* in the inputs array so this class
can read its input values
*/
void _7411::input_to_pin(logic_object* input, int pin){
	inputs[pin]=input;
}

/*
The restructure function for _7400 updates each output pin's truth value
*/
void _7411::restructure(){
	vector<bool> output_changed;
	
	for(int i=0; i<3; ++i)
		output_changed.push_back(restructure_pin(i));
	
	for(int i=0; i<3; i++){
		if(output_changed[i])
			output_objects[i]->restructure();
	}
}

void evaluate(){
	for(int i=0; i<3; i++){
		evaluate_pin(i);
	}
}

bool _7411::evaluate_pin(int pin){
	outputs[pin]=true;
	
	vector<logic_object*> pins;
	pins.push_back(inputs[3*pin]);
	pins.push_back(inputs[3*pin+1]);
	pins.push_back(inputs[3*pin+2]);

	for(int i=0; i<3; i++){
		if(pins[i]!=NULL){
			if(pins[i]->is_chip()){
				bool value=pins[i]->value(this, 3*pin+i);
				if(!value){
					outputs[pin]=false;
					return outputs[pin];
				}
			}
			else{
				bool value=pins[i]->value();
				if(!value){
					outputs[pin]=false;
					return outputs[pin];
				}
			}	
		}			
	}
	return outputs[pin];
}

bool _7411::restructure_pin(int pin){
	bool prev_value=outputs[pin];
	evaluate_pin(pin);
	
	if(output_objects[pin] && prev_value!=outputs[pin])
		return true;
	return false;
}

vector<bool> _7411::value(logic_object* obj){
	vector<bool> pin_values;
	list<pin> pin_numbers= pins[obj];
	list<pin>::iterator pin_itr= pin_numbers.begin();
	
	while(pin_itr!=pin_numbers.end()){
		int pin_value=pin_itr->value;
		pin_values.push_back(outputs[pin_value]);
		pin_itr++;
	}
	return pin_values;
}

bool _7411::value(logic_object* obj, int pin_){
	int value;
	list<pin> pin_numbers= pins[obj];
	list<pin>::iterator pin_itr= pin_numbers.begin();
	
	while(pin_itr!=pin_numbers.end()){
		if(pin_itr->output_pin==pin_){
			return pin_itr->value;
		}
	}
	return 0;
}

bool _7411::outputs_filled(){
	if(pins.size()==num_outputs)
		return true;
	return false;
}

bool _7411::output_connected(int pin){
	if(output_objects[pin])
		return true;
	else
		return false;
}

void _7411::print_value(){
	for(int i=0; i<3; ++i){
		cout<<"Value of pin "<<i<<" is: "<<outputs[i]<<endl;
	}
}